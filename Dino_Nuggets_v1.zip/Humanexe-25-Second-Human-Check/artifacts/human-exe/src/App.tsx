import { useEffect, useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
type Screen = 'start' | 'playing' | 'result';
type Feedback = '' | 'correct' | 'wrong';
type PartKind = 'head' | 'body' | 'tail';
type Mole = { id: number; hat: boolean; hole: number };
const reference = { head: 'crest', body: 'spotted', tail: 'long' };
const options: Record<PartKind, string[]> = {
  head: ['crest', 'horns', 'round'],
  body: ['spotted', 'striped', 'plain'],
  tail: ['long', 'club', 'stubby'],
};
const partLabels: Record<PartKind, string> = { head: 'Head', body: 'Body', tail: 'Tail' };

function PixelDino({ head = 'crest', body = 'spotted', tail = 'long', hat = false, upwardTail = false, className = '' }: {
  head?: string; body?: string; tail?: string; hat?: boolean; upwardTail?: boolean; className?: string;
}) {
  const bodyColor = body === 'striped' ? '#c7763e' : body === 'plain' ? '#a9bd74' : '#78a96a';
  return (
    <svg className={`pixel-dino ${className}`} viewBox="0 0 150 110" role="img" aria-label={`${head} head, ${body} body, ${upwardTail ? 'upward' : 'sideways'} tail dinosaur${hat ? ' wearing an orange hat' : ''}`} shapeRendering="crispEdges">
      <g stroke="#234a38" strokeWidth="5" strokeLinejoin="round">
        <path fill={bodyColor} d={upwardTail ? 'M104 68 125 47 133 21 145 19 140 49 123 77 105 87Z' : 'M104 70 130 61 147 65 147 76 128 77 111 87Z'} />
        <path fill={bodyColor} d="M38 48 50 31 77 27 100 38 112 62 105 87 47 88 35 72Z" />
        {body === 'spotted' && <g fill="#f0a65b" stroke="none"><rect x="63" y="53" width="10" height="10"/><rect x="87" y="66" width="8" height="8"/><rect x="49" y="69" width="7" height="7"/></g>}
        {body === 'striped' && <g fill="#f1bd74" stroke="none"><path d="M53 40h8v42h-8zM76 36h8v49h-8zM98 46h7v34h-7z"/></g>}
        <path fill={bodyColor} d="M49 78h13v23H48zM88 78h13v23H87z" />
        <path fill={bodyColor} d={head === 'horns' ? 'M29 20 36 9 43 22 53 17 62 29 66 49 57 63 29 61 18 48 20 31Z' : head === 'round' ? 'M29 28 38 16 58 16 69 27 69 48 58 60 31 58 20 47 20 36Z' : 'M27 24 38 11 60 15 69 27 67 49 56 61 29 59 19 47 20 34Z'} />
        {head === 'crest' && <path fill="#ef8a3b" d="m39 15 2-12 9 10 7-12 5 16Z" />}
        {head === 'horns' && <path fill="#f2d79e" d="m23 28-8-9 2 17 8 3m34-17 9-9-2 17-8 2" />}
        <path fill="#f7ebd0" stroke="none" d="M52 34h7v8h-7z" />
        <path fill="#234a38" stroke="none" d="M55 37h4v4h-4z" />
        <path fill="#ef8a3b" d="M28 49h22v8H28z" />
        {hat && <g><path fill="#f18b3b" d="M27 13h30v8H27zM32 6h20v8H32z" /><path fill="#d96531" stroke="none" d="M32 18h21v3H32z" /></g>}
      </g>
    </svg>
  );
}

function Home() {
  const [screen, setScreen] = useState<Screen>('start');
  const [round, setRound] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(25);
  const [feedback, setFeedback] = useState<Feedback>('');
  const [feedbackText, setFeedbackText] = useState('');
  const [outcome, setOutcome] = useState<'pass' | 'timeout' | null>(null);
  const [hits, setHits] = useState(0);
  const [mole, setMole] = useState<Mole | null>(null);
  const [selected, setSelected] = useState<Record<PartKind, string | null>>({ head: null, body: null, tail: null });
  const [soundOn, setSoundOn] = useState(false);
  const [lastWhack, setLastWhack] = useState<number | null>(null);
  const deadlineRef = useRef(0);
  const generationRef = useRef(0);
  const timeoutRefs = useRef<number[]>([]);
  const queueRef = useRef<Mole[]>([]);
  const activeRef = useRef<Mole | null>(null);
  const activeMoleTimerRef = useRef<number | null>(null);
  const hitsRef = useRef(0);
  const feedbackTimer = useRef<number | null>(null);
  const audioRef = useRef<AudioContext | null>(null);

  const clearActiveMoleTimer = () => {
    if (activeMoleTimerRef.current !== null) {
      window.clearTimeout(activeMoleTimerRef.current);
      timeoutRefs.current = timeoutRefs.current.filter((id) => id !== activeMoleTimerRef.current);
      activeMoleTimerRef.current = null;
    }
  };
  const clearFeedbackTimer = () => {
    if (feedbackTimer.current !== null) window.clearTimeout(feedbackTimer.current);
    feedbackTimer.current = null;
  };
  const clearTimers = () => {
    clearActiveMoleTimer();
    timeoutRefs.current.forEach((id) => window.clearTimeout(id));
    timeoutRefs.current = [];
    clearFeedbackTimer();
  };
  const playTone = (frequency: number, duration = 0.085, type: OscillatorType = 'square') => {
    if (!soundOn) return;
    try {
      const AudioContextClass = window.AudioContext;
      if (!AudioContextClass) return;
      const context = audioRef.current ?? new AudioContextClass();
      audioRef.current = context;
      if (context.state === 'suspended') void context.resume();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = type;
      oscillator.frequency.setValueAtTime(frequency, context.currentTime);
      gain.gain.setValueAtTime(0.045, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + duration);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start();
      oscillator.stop(context.currentTime + duration);
    } catch { /* Audio is optional; the game always remains playable. */ }
  };
  const later = (fn: () => void, ms: number, generation: number) => {
    const id = window.setTimeout(() => {
      timeoutRefs.current = timeoutRefs.current.filter((item) => item !== id);
      if (generationRef.current === generation) fn();
    }, ms);
    timeoutRefs.current.push(id);
    return id;
  };
  const showFeedback = (type: Feedback, text: string, duration = 620) => {
    clearFeedbackTimer();
    setFeedback(type);
    setFeedbackText(text);
    feedbackTimer.current = window.setTimeout(() => {
      setFeedback('');
      setFeedbackText('');
      feedbackTimer.current = null;
    }, duration);
  };
  const finishTimeout = () => {
    clearTimers();
    generationRef.current += 1;
    activeRef.current = null;
    setMole(null);
    setFeedback('');
    setOutcome('timeout');
    setSecondsLeft(0);
    setScreen('result');
  };
  const finishPass = () => {
    if (Date.now() >= deadlineRef.current) { finishTimeout(); return; }
    clearTimers();
    generationRef.current += 1;
    activeRef.current = null;
    setMole(null);
    setFeedback('correct');
    setOutcome('pass');
    setScreen('result');
    playTone(880, 0.2, 'triangle');
    later(() => playTone(1175, 0.24, 'triangle'), 150, generationRef.current);
  };
  const beginRun = () => {
    clearTimers();
    generationRef.current += 1;
    const generation = generationRef.current;
    activeRef.current = null;
    queueRef.current = [];
    hitsRef.current = 0;
    deadlineRef.current = Date.now() + 25_000;
    setSecondsLeft(25);
    setRound(0);
    setHits(0);
    setMole(null);
    setLastWhack(null);
    setSelected({ head: null, body: null, tail: null });
    setFeedback('');
    setFeedbackText('');
    setOutcome(null);
    setScreen('playing');
    const sequence: Mole[] = [];
    for (let i = 0; i < 3; i++) sequence.push({ id: i, hat: true, hole: Math.floor(Math.random() * 9) });
    for (let i = 0; i < 3; i++) sequence.push({ id: i + 3, hat: false, hole: Math.floor(Math.random() * 9) });
    sequence.sort(() => Math.random() - 0.5);
    queueRef.current = sequence;
    later(() => spawnMole(generation), 300, generation);
  };
  const spawnMole = (generation: number) => {
    if (generationRef.current !== generation || Date.now() >= deadlineRef.current) return;
    let next = queueRef.current.shift();
    if (!next && hitsRef.current < 3) next = { id: 20 + hitsRef.current + Math.floor(Math.random() * 1000), hat: true, hole: Math.floor(Math.random() * 9) };
    if (!next) return;
    const previous = activeRef.current;
    if (previous && previous.hat) {
      queueRef.current.push({ ...previous, hole: (previous.hole + 1 + Math.floor(Math.random() * 8)) % 9 });
      next = queueRef.current.shift() ?? next;
    }
    if (previous && previous.hole === next.hole) next = { ...next, hole: (next.hole + 1 + Math.floor(Math.random() * 8)) % 9 };
    activeRef.current = next;
    setMole(next);
    playTone(410, 0.05);
    activeMoleTimerRef.current = later(() => {
      activeMoleTimerRef.current = null;
      if (activeRef.current?.id !== next?.id) return;
      activeRef.current = null;
      setMole(null);
      later(() => spawnMole(generation), 130, generation);
    }, 1050, generation);
  };
  const whack = (hole: number) => {
    if (screen !== 'playing' || round !== 0 || Date.now() >= deadlineRef.current) {
      if (screen === 'playing' && Date.now() >= deadlineRef.current) finishTimeout();
      return;
    }
    const active = activeRef.current;
    if (!active || active.hole !== hole) return;
    clearActiveMoleTimer();
    activeRef.current = null;
    setMole(null);
    setLastWhack(hole);
    if (!active.hat) {
      showFeedback('wrong', 'No hat! Keep your eyes peeled.');
      playTone(170, 0.12, 'triangle');
      later(() => spawnMole(generationRef.current), 260, generationRef.current);
      return;
    }
    hitsRef.current += 1;
    setHits(hitsRef.current);
    showFeedback('correct', 'Nice catch!');
    playTone(720, 0.08);
    if (hitsRef.current === 3) {
      later(() => { if (Date.now() < deadlineRef.current) { clearFeedbackTimer(); setRound(1); setFeedback(''); setFeedbackText(''); setHits(3); } else finishTimeout(); }, 420, generationRef.current);
    } else later(() => spawnMole(generationRef.current), 250, generationRef.current);
  };
  const selectPart = (kind: PartKind, value: string) => {
    if (screen !== 'playing' || round !== 1 || Date.now() >= deadlineRef.current) {
      if (screen === 'playing' && Date.now() >= deadlineRef.current) finishTimeout();
      return;
    }
    const next = { ...selected, [kind]: value };
    setSelected(next);
    if (next.head && next.body && next.tail) {
      if (next.head === reference.head && next.body === reference.body && next.tail === reference.tail) {
        showFeedback('correct', 'Perfect match — dino assembled!');
        playTone(620, 0.12, 'triangle');
        later(() => { if (Date.now() < deadlineRef.current) { clearFeedbackTimer(); setRound(2); setFeedback(''); setFeedbackText(''); } else finishTimeout(); }, 500, generationRef.current);
      } else {
        showFeedback('wrong', 'Not quite. Compare each piece and try again.');
        playTone(180, 0.1, 'triangle');
      }
    }
  };
  const chooseImpostor = (index: number) => {
    if (screen !== 'playing' || round !== 2 || Date.now() >= deadlineRef.current) {
      if (screen === 'playing' && Date.now() >= deadlineRef.current) finishTimeout();
      return;
    }
    if (index === 2) finishPass();
    else {
      showFeedback('wrong', 'Not that one. Look closely at the tails.');
      playTone(180, 0.1, 'triangle');
    }
  };
  useEffect(() => {
    if (screen !== 'playing') return;
    const tick = () => {
      const remain = deadlineRef.current - Date.now();
      if (remain <= 0) finishTimeout();
      else setSecondsLeft(Math.ceil(remain / 1000));
    };
    tick();
    const interval = window.setInterval(tick, 100);
    return () => window.clearInterval(interval);
  }, [screen]);
  useEffect(() => () => {
    clearTimers();
    if (audioRef.current) void audioRef.current.close();
  }, []);
  const progress = screen === 'playing' ? (round === 0 ? 1 : round === 1 ? 2 : 3) : 0;
  const toggleSound = () => {
    if (!soundOn) {
      try {
        const AudioContextClass = window.AudioContext;
        if (AudioContextClass) {
          const context = audioRef.current ?? new AudioContextClass();
          audioRef.current = context;
          if (context.state === 'suspended') void context.resume();
        }
      } catch { /* Sound toggle is safe in browsers without Web Audio. */ }
    }
    setSoundOn((value) => !value);
  };

  return (
    <div className="game-shell" data-testid="dino-nuggets-game">
      <header className="topbar" data-testid="game-header">
        <div className="brand-lockup" aria-label="Dino Nuggets"><span className="brand-mark" aria-hidden="true"><PixelDino className="brand-dino" /></span><span className="brand-name">DINO <b>NUGGETS</b></span></div>
        <div className="header-actions">
          <button className={`sound-toggle${soundOn ? ' sound-on' : ''}`} onClick={toggleSound} aria-pressed={soundOn} data-testid="sound-toggle"><span aria-hidden="true">SFX</span> Sound {soundOn ? 'on' : 'off'}</button>
          {screen === 'playing' ? <button className="restart-link" onClick={beginRun} data-testid="restart-game">Restart run</button> : <span className="top-tag"><span className="status-light" /> A tiny prehistoric test</span>}
        </div>
      </header>
      <main className="game-main">
        {screen === 'start' && <section className="start-screen" aria-labelledby="hero-title">
          <div className="hero-copy">
            <p className="eyebrow"><span className="eyebrow-dot" /> A small game with big dino energy</p>
            <h1 className="hero-title" id="hero-title">Dino<br /><span>Nuggets</span></h1>
            <p className="hero-subtitle">Prove you're human.<br /><strong>Don't let the dinosaurs down.</strong></p>
            <p className="game-disclaimer" data-testid="game-disclaimer">A playful game inspired by CAPTCHA — not a security system.</p>
            <button className="primary-button" onClick={beginRun} data-testid="start-game">Start the adventure <span aria-hidden="true">→</span></button>
            <p className="time-note"><span className="mini-clock" aria-hidden="true" /> Three challenges. 25 seconds. Ready?</p>
          </div>
          <div className="hero-art" aria-label="A friendly dinosaur wearing an orange hat">
            <div className="sun-disc" />
            <div className="hero-badge">DINO<br />WHACK<br /><b>EST. 65M BC</b></div>
            <PixelDino hat className="hero-dino" />
            <span className="hero-spark spark-one" aria-hidden="true" /><span className="hero-spark spark-two" aria-hidden="true" />
            <div className="art-ground"><i /><i /><i /><i /><i /></div>
          </div>
          <div className="challenge-preview">
            <span className="preview-number">01</span><div><b>Dino Whack</b><small>Catch three orange hats</small></div>
            <span className="preview-arrow">→</span>
            <span className="preview-number">02</span><div><b>Build-a-Dino</b><small>Rebuild the reference</small></div>
            <span className="preview-arrow">→</span>
            <span className="preview-number">03</span><div><b>Prehistoric Impostor</b><small>Spot the odd tail out</small></div>
          </div>
        </section>}
        {screen === 'playing' && <section className="play-area" aria-labelledby="round-title" data-testid="game-round">
          <div className="play-head">
            <div><p className="round-label" data-testid="round-indicator">CHALLENGE 0{progress} <span>/ 03</span></p><h1 className="round-title" id="round-title" data-testid="round-title">{['Dino Whack', 'Build-a-Dino', 'Spot the Prehistoric Impostor'][round]}</h1></div>
            <div className={`timer-box${secondsLeft <= 5 ? ' is-low' : ''}`} aria-label={`${secondsLeft} seconds remaining`} data-testid="countdown"><span className="timer-clock" aria-hidden="true" /><span>{String(secondsLeft).padStart(2, '0')}<small>s</small></span></div>
          </div>
          <div className="progress-block"><div className="progress-meta"><span>Three tiny trials</span><span data-testid="progress-status">{progress} / 3</span></div><div className="progress-track" role="progressbar" aria-valuemin={0} aria-valuemax={3} aria-valuenow={progress} aria-label="Challenge progress"><div className="progress-fill" style={{ width: `${progress / 3 * 100}%` }} /></div></div>
          <div className="question-panel" key={round}>
            <div className="panel-topline"><span className="panel-kicker">{['01 / quick paws', '02 / put it together', '03 / sharp eyes'][round]}</span><span className="panel-fern" aria-hidden="true" /></div>
            <div className="panel-body">
              {round === 0 && <div className="whack-game">
                <div className="challenge-intro"><div><h2 className="question-prompt">Tap only the dinosaurs wearing orange hats!</h2><p className="instruction-note">Three hat-wearing dinos. Leave the hatless ones be.</p></div><div className="hit-counter" aria-label={`${hits} of 3 target dinosaurs caught`} data-testid="hit-counter"><span>{hits}</span><small>/ 3<br />CAUGHT</small></div></div>
                <div className="burrow-grid" role="group" aria-label="Dinosaur burrow grid" data-testid="burrow-grid">
                  {Array.from({ length: 9 }, (_, index) => <button key={index} className={`burrow${mole?.hole === index ? ' has-dino' : ''}${lastWhack === index ? ' just-hit' : ''}`} onClick={() => whack(index)} aria-label={mole?.hole === index ? `Dinosaur ${mole.hat ? 'wearing orange hat' : 'without hat'}, burrow ${index + 1}` : `Empty burrow ${index + 1}`} data-testid={`burrow-${index}`}>
                    <span className="burrow-earth" />
                    {mole?.hole === index && <span className="mole-pop" data-testid="active-dinosaur"><PixelDino hat={mole.hat} className="mole-dino" /></span>}
                    <span className="burrow-hole" />
                  </button>)}
                </div>
                <p className={`feedback${feedback === 'wrong' ? ' wrong' : ''}`} role="status" aria-live="polite" data-testid="answer-feedback">{feedbackText || 'A dino is just about to pop up…'}</p>
              </div>}
              {round === 1 && <div className="build-game">
                <div className="challenge-intro"><div><h2 className="question-prompt">Rebuild this exact dino.</h2><p className="instruction-note">Choose one head, body and tail to match the model.</p></div><div className="reference-chip">REFERENCE</div></div>
                <div className="reference-stage" data-testid="reference-dinosaur"><PixelDino {...reference} className="reference-dino" /><span>THE ONE TO BUILD</span></div>
                <div className="part-picker">
                  {(['head', 'body', 'tail'] as PartKind[]).map((kind) => <fieldset className="part-category" key={kind} data-testid={`part-category-${kind}`}><legend>{partLabels[kind]} <span>{selected[kind] ? '✓ selected' : 'pick one'}</span></legend><div className="part-options">{options[kind].map((value, index) => <button key={value} className={`part-option${selected[kind] === value ? ' selected' : ''}`} onClick={() => selectPart(kind, value)} disabled={feedback === 'correct'} aria-pressed={selected[kind] === value} aria-label={`${partLabels[kind]} option ${index + 1}: ${value}`} data-testid={`part-${kind}-${value}`}><PixelDino {...{ [kind]: value }} className="part-dino" /><span>{value}</span></button>)}</div></fieldset>)}
                </div>
                <p className={`feedback${feedback === 'wrong' ? ' wrong' : ''}`} role="status" aria-live="polite" data-testid="answer-feedback">{feedbackText || 'Every piece can be changed until it clicks.'}</p>
              </div>}
              {round === 2 && <div className="impostor-game">
                <div className="challenge-intro"><div><h2 className="question-prompt">Most tails point sideways. Find the only dinosaur with an upward tail.</h2><p className="instruction-note">One tail breaks the pattern.</p></div><span className="tail-clue" aria-hidden="true">↑</span></div>
                <div className="impostor-grid" role="group" aria-label="Choose the dinosaur with an upward tail" data-testid="impostor-choices">
                  {[0, 1, 2, 3].map((index) => <button key={index} className="impostor-option" onClick={() => chooseImpostor(index)} aria-label={`Dinosaur ${index + 1}, tail points ${index === 2 ? 'upward' : 'sideways'}`} data-testid={`impostor-choice-${index}`}><span className="dino-number">0{index + 1}</span><PixelDino body={['plain', 'spotted', 'striped', 'plain'][index]} head={['round', 'crest', 'horns', 'round'][index]} upwardTail={index === 2} className="impostor-dino" /><span className={`tail-direction${index === 2 ? ' up' : ''}`}>{index === 2 ? 'TAIL UP' : 'TAIL SIDEWAYS'}</span></button>)}
                </div>
                <p className={`feedback${feedback === 'wrong' ? ' wrong' : ''}`} role="status" aria-live="polite" data-testid="answer-feedback">{feedbackText || 'Choose the one that breaks the tail rule.'}</p>
              </div>}
            </div>
          </div>
        </section>}
        {screen === 'result' && <section className="result-panel" aria-labelledby="result-title" data-testid="game-result">
          <div className="result-scenery"><span className="result-sun" /><PixelDino hat className="result-dino" /><span className="result-confetti" aria-hidden="true" /></div>
          <div className="result-copy"><p className="eyebrow">{outcome === 'pass' ? 'THE DINO CREW APPROVES' : 'THE CLOCK GOT AWAY'}</p><h1 id="result-title" className="result-title" data-testid="result-title">{outcome === 'pass' ? 'You saved the nuggets!' : 'Time’s up, explorer.'}</h1><p data-testid="result-message">{outcome === 'pass' ? 'Three challenges conquered. These little dinosaurs knew you had it in you.' : 'The adventure paused at 00:00. The dinos are ready when you are.'}</p><button className="primary-button" onClick={beginRun} data-testid="play-again">{outcome === 'pass' ? 'Play again' : 'Try again'} <span aria-hidden="true">↻</span></button></div>
           <div className="result-score"><span>YOUR FIELD NOTES</span><b data-testid="completed-challenges">{outcome === 'pass' ? '3' : String(round)} / 3</b><small>prehistoric trials</small></div>
        </section>}
      </main>
      <footer className="footer-note" data-testid="game-footer"><span>DINOSAURS ARE COUNTING ON YOU</span><span>Just a game · not a security system</span></footer>
    </div>
  );
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}
export default App;
